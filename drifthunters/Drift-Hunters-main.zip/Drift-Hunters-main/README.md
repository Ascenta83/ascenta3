# Drift-Hunters
Drift Hunters unblocked game as a html, Just download the file as a .zip
Then go to files and open the html file.
Then Done

